package ExcelData;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class OrangeLocators {
	WebDriver driver;
	public OrangeLocators(WebDriver driver) {
		this.driver=driver;
		
	}

	public void enterusername(String uname) {
		driver.findElement(By.id("txtUsername")).sendKeys(uname);
	}
	public void enterPassword(String pwd) {
		driver.findElement(By.id("txtPassword")).sendKeys(pwd);
	}
	public void clickonlogin() {
		driver.findElement(By.id("btnLogin")).click();
	}


}


