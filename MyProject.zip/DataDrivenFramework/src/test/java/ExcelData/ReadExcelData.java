package ExcelData;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import org.apache.commons.io.FileUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class ReadExcelData {
	   private static  Logger log=LogManager.getLogger(ReadExcelData.class);
	@Test
	public void login() throws Exception {
		System.out.println(System.getProperty("user.dir"));
		String fpath= System.getProperty("user.dir");
		File f=new File(fpath+"//src//main//resources//TestData.xlsx"); 
		FileInputStream fis=new FileInputStream(f);
		XSSFWorkbook workbook=new XSSFWorkbook(fis);
		XSSFSheet sheet=workbook.getSheet("Sheet1");
		FileOutputStream fo=new FileOutputStream(fpath+"//src//main//resources//TestData.xlsx");
		     int rows= sheet.getPhysicalNumberOfRows();
		     System.out.println(rows);
		     System.setProperty("webdriver.chrome.driver",fpath+"//src//main//resources//chromedriver.exe");
       	  WebDriver driver=new ChromeDriver();
       	 int s1=1;
	      int s2=1;
	      XSSFRow row;
	      XSSFCell cell;
	       String pa="pass";
	       String fa="fail";
	      for(int i=1; i<rows; i++) {
		            	 OrangeLocators loc=new OrangeLocators(driver);
		          		 log.info("browser lunching");
		          		driver.manage().window().maximize();
		          		driver.get("https://opensource-demo.orangehrmlive.com/index.php/auth/login");
		          		log.info("entering url");
		            	  row= sheet.getRow(i);
		           int cells= row.getPhysicalNumberOfCells();
		            	      for(int j=0; j<cells; j++) {
		            	    	  cell= row.getCell(j);
		            	    	      String cellValue= cell.getStringCellValue();
		            	                if(j==0) {
		            	    	    	  log.info("entering username");
		            	    	     	  loc.enterusername(cellValue);
		            	    	    	  }else {
		            	    	    	  log.info("entering password");
		            	    	    	  loc.enterPassword(cellValue);
		            	    					            	    			  
		            	    				}
		            	    			
		            	    	      }
		            	      log.info("click on login button");
		            	       loc.clickonlogin();
		            	      Thread.sleep(3000);
		            	      
		            	     String curl= driver.getCurrentUrl();
		            	      
		            	     if(curl.equals("https://opensource-demo.orangehrmlive.com/index.php/dashboard")) {
		            	     row.createCell(2).setCellValue(pa);
		            	    	 TakesScreenshot ts=(TakesScreenshot) driver; 
		            	 File src= ts.getScreenshotAs(OutputType.FILE);
		            	 File des=new File(fpath+"\\src\\test\\resources\\Passedimg\\ "+"img "+s1+".png");
		            	    	 FileUtils.copyFile(src,des);        		
             			 			s1++;
		            	    	 Thread.sleep(3000);
		            	    	driver.findElement(By.xpath("//div[@id='branding']/child::a[@id='welcome']")).click();
				            	  	Thread.sleep(3000);
				            	driver.findElement(By.xpath("(//div[@id='welcome-menu']/ul/child::li)[2]/a")).click();
				            	  		            	    	 
		            	     }else {
		            	    	 
		            	    	 row.createCell(2).setCellValue(fa);		            	    	
		            	    	 TakesScreenshot ts=(TakesScreenshot) driver;
		            	     	 File src= ts.getScreenshotAs(OutputType.FILE);
		            	 File des=new File(fpath+"\\src\\test\\resources\\Failedimg\\ "+row.getCell(0).getStringCellValue()+".png");
		            	    				 FileUtils.copyFile(src, des);
		            		    	    	    	 s2++;
		            	    	 }            	      
		            	      	            	    
		            	        }
		              workbook.write(fo);
		              
		              driver.close();
		      	                  	  
		              		            	     
		    }

}
